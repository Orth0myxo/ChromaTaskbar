@echo off
setlocal
set "DOTNET_ROOT=%~dp0runtime"
set "DOTNET_ROOT_X64=%DOTNET_ROOT%"
set "DOTNET_MULTILEVEL_LOOKUP=0"
if not exist "%~dp0app\ChromaTaskbar.exe" (
  echo ChromaTaskbar.exe is missing. Extract the complete portable ZIP and try again.
  pause
  exit /b 2
)
start "" "%~dp0app\ChromaTaskbar.exe"
exit /b 0
