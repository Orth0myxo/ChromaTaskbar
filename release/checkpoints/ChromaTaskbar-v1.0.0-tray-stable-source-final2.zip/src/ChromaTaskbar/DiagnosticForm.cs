using ChromaTaskbar.Core;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace ChromaTaskbar;

internal sealed class DiagnosticForm : Form
{
    private readonly ForegroundMonitor _monitor = new();
    private readonly WindowCapturer _capturer = new();
    private readonly DominantColorAnalyzer _analyzer = new();
    private readonly ColorSmoother _smoother = new();
    private readonly TranslucentTbSettingsController _taskbar;
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 500 };
    private readonly Label _app = ValueLabel();
    private readonly Label _title = ValueLabel();
    private readonly Label _class = ValueLabel();
    private readonly Label _capture = ValueLabel();
    private readonly Label _color = ValueLabel();
    private readonly Panel _preview = new() { Width = 84, Height = 48, BorderStyle = BorderStyle.FixedSingle, BackColor = Color.FromArgb(32, 32, 32) };
    private readonly Icon _windowIcon;
    private string? _taskbarError;
    private CapturedFrame? _lastFrame;
    private ForegroundWindowInfo? _lastFrameTarget;
    private RgbColor? _lastAnalyzedColor;
    private RgbColor? _lastShownColor;
    private int _refreshQueued;
    private bool _paused;
    private bool _allowClose;

    internal DiagnosticForm(TranslucentTbSettingsController? taskbar = null)
    {
        _taskbar = taskbar ?? new TranslucentTbSettingsController();
        Text = "ChromaTaskbar";
        _windowIcon = LoadApplicationIcon();
        Icon = _windowIcon;
        ClientSize = new Size(620, 350);
        MinimumSize = new Size(580, 330);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10F);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 2,
            RowCount = 6,
            AutoSize = false
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 132));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        for (int i = 0; i < 5; i++)
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 16));
        }
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 20));

        AddRow(layout, 0, "Application", _app);
        AddRow(layout, 1, "Window title", _title);
        AddRow(layout, 2, "Window type", _class);
        AddRow(layout, 3, "Status", _capture);
        AddRow(layout, 4, "Taskbar colour", _color);
        AddRow(layout, 5, "Preview", _preview);
        Controls.Add(layout);

        try
        {
            _taskbar.Start();
        }
        catch (Exception exception)
        {
            _taskbarError = $"TTB settings unavailable: {exception.Message}";
        }

        _monitor.ForegroundChanged += OnForegroundChanged;
        _monitor.Start();
        _monitor.Refresh();
        _timer.Tick += (_, _) => RefreshDiagnostic();
        _timer.Start();
        FormClosing += (_, e) =>
        {
            if (!_allowClose)
            {
                e.Cancel = true;
                Hide();
            }
        };
        FormClosed += (_, _) =>
        {
            _timer.Stop();
            _timer.Dispose();
            _monitor.ForegroundChanged -= OnForegroundChanged;
            _monitor.Dispose();
            _windowIcon.Dispose();
            try
            {
                _taskbar.Dispose();
            }
            catch (Exception exception)
            {
                string backup = _taskbar.BackupPath ?? "No backup path was recorded.";
                MessageBox.Show(
                    $"ChromaTaskbar could not restore the original TranslucentTB settings. The saved original copy is at:\r\n{backup}\r\n\r\nDetails: {exception.Message}",
                    "ChromaTaskbar settings restore failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        };
    }

    internal bool IsPaused => _paused;
    internal bool IsProcessing => !_paused && _timer.Enabled;
    internal string? StartupError => _taskbarError;

    internal void PauseDetection()
    {
        if (_paused || IsDisposed)
        {
            return;
        }

        _timer.Stop();
        _monitor.Stop();
        _paused = true;
        try
        {
            _taskbar.Pause();
            _capture.Text = "Colour detection paused.";
        }
        catch (Exception exception)
        {
            _taskbarError = $"Paused; TTB restore failed: {exception.Message}";
            _capture.Text = _taskbarError;
        }
    }

    internal void ResumeDetection()
    {
        if (!_paused || IsDisposed)
        {
            return;
        }

        try
        {
            _taskbar.Resume();
        }
        catch (Exception exception)
        {
            _taskbarError = $"Resume failed: {exception.Message}";
            _capture.Text = _taskbarError;
            return;
        }

        _paused = false;
        _monitor.Start();
        _monitor.Refresh();
        _timer.Start();
        RefreshDiagnostic();
    }

    internal void ExitAndClose()
    {
        if (IsDisposed)
        {
            return;
        }

        _allowClose = true;
        Close();
    }

    private void RefreshDiagnostic()
    {
        ForegroundWindowInfo foreground = _monitor.Current;
        ForegroundWindowInfo? target = ForegroundTargetResolver.Select(
            foreground,
            (uint)Environment.ProcessId);
        if (target is null)
        {
            _app.Text = "(no active application)";
            _title.Text = string.Empty;
            _class.Text = string.Empty;
            if (_taskbarError is not null)
            {
                _capture.Text = _taskbarError;
                return;
            }

            if (!_taskbar.IsReady)
            {
                _capture.Text = "TranslucentTB settings controller is not ready.";
                return;
            }

            try
            {
                _taskbar.SetDesktopAppearance();
                _capture.Text = "Desktop transparency active.";
            }
            catch (Exception exception)
            {
                _capture.Text = $"TTB update failed: {exception.Message}";
            }

            return;
        }

        ForegroundWindowInfo info = target;
        _app.Text = string.IsNullOrWhiteSpace(info.ProcessName) ? "(unavailable)" : info.ProcessName;
        _title.Text = string.IsNullOrWhiteSpace(info.WindowTitle) ? "(no title)" : info.WindowTitle;
        _class.Text = string.IsNullOrWhiteSpace(info.WindowClass) ? "(unavailable)" : info.WindowClass;

        CaptureResult result = _capturer.Capture(info);
        if (!result.Success || result.Frame is null)
        {
            _capture.Text = $"Failed: {result.FailureReason} — {result.Message}";
            AppendTaskbarError();
            return;
        }

        if (!IsStillCurrentTarget(info))
        {
            _capture.Text = $"Discarded stale capture: {result.Frame.Width}×{result.Frame.Height}, {result.Duration.TotalMilliseconds:F0} ms";
            AppendTaskbarError();
            return;
        }

        if (_lastFrame is not null &&
            _lastFrameTarget is not null &&
            ForegroundTargetResolver.IsSameTarget(_lastFrameTarget, info) &&
            _lastFrame.HasSamePixels(result.Frame))
        {
            if (_lastAnalyzedColor is RgbColor priorSample)
            {
                _smoother.TryAdd(priorSample, DateTime.UtcNow, out RgbColor cachedSmoothed);
                RgbColor cachedShown = _smoother.Current ?? cachedSmoothed;
                _lastShownColor = cachedShown;
                _color.Text = $"{cachedShown}  (unchanged content)";
                _preview.BackColor = Color.FromArgb(cachedShown.R, cachedShown.G, cachedShown.B);
            }

            Stopwatch applyTimer = Stopwatch.StartNew();
            ApplyLastColor();
            applyTimer.Stop();
            _capture.Text = $"Success: {result.Frame.Width}×{result.Frame.Height}, {result.Duration.TotalMilliseconds:F0} ms; unchanged frame, analysis skipped; apply {applyTimer.Elapsed.TotalMilliseconds:F1} ms";
            AppendTaskbarError();
            return;
        }

        Stopwatch analysisTimer = Stopwatch.StartNew();
        DominantColorResult color = _analyzer.Analyze(result.Frame);
        analysisTimer.Stop();

        if (!IsStillCurrentTarget(info))
        {
            _capture.Text = $"Discarded stale capture after analysis: {result.Frame.Width}×{result.Frame.Height}";
            AppendTaskbarError();
            return;
        }

        _smoother.TryAdd(color.Rgb, DateTime.UtcNow, out RgbColor smoothed);
        RgbColor shown = _smoother.Current ?? smoothed;
        _lastFrame = result.Frame;
        _lastFrameTarget = info;
        _lastAnalyzedColor = color.Rgb;
        _lastShownColor = shown;
        _color.Text = $"{shown}  (confidence {color.Confidence:P0})";
        _preview.BackColor = Color.FromArgb(shown.R, shown.G, shown.B);
        Stopwatch apply = Stopwatch.StartNew();

        if (_taskbarError is null)
        {
            try
            {
                _taskbar.ApplyColor(shown);
            }
            catch (Exception exception)
            {
                _taskbarError = $"TTB update failed: {exception.Message}";
            }
        }
        apply.Stop();

        _capture.Text = $"Success: {result.Frame.Width}×{result.Frame.Height}; capture {result.Duration.TotalMilliseconds:F1} ms, analysis {analysisTimer.Elapsed.TotalMilliseconds:F1} ms, apply {apply.Elapsed.TotalMilliseconds:F1} ms";

        AppendTaskbarError();
    }

    private void OnForegroundChanged(object? sender, ForegroundWindowInfo info)
    {
        if (IsDisposed || !IsHandleCreated || Interlocked.Exchange(ref _refreshQueued, 1) != 0)
        {
            return;
        }

        try
        {
            BeginInvoke((Action)(() =>
            {
                Interlocked.Exchange(ref _refreshQueued, 0);
                if (!IsDisposed)
                {
                    RefreshDiagnostic();
                }
            }));
        }
        catch (InvalidOperationException)
        {
            Interlocked.Exchange(ref _refreshQueued, 0);
        }
    }

    private bool IsStillCurrentTarget(ForegroundWindowInfo expected)
    {
        _monitor.Refresh();
        ForegroundWindowInfo? current = ForegroundTargetResolver.Select(
            _monitor.Current,
            (uint)Environment.ProcessId);
        return ForegroundTargetResolver.IsSameTarget(expected, current);
    }

    private void ApplyLastColor()
    {
        if (_lastShownColor is RgbColor color && _taskbarError is null)
        {
            try
            {
                _taskbar.ApplyColor(color);
            }
            catch (Exception exception)
            {
                _taskbarError = $"TTB update failed: {exception.Message}";
            }
        }
    }

    private void AppendTaskbarError()
    {
        if (_taskbarError is not null)
        {
            _capture.Text += $" — {_taskbarError}";
        }
    }

    private static Label ValueLabel() => new()
    {
        AutoEllipsis = true,
        Dock = DockStyle.Fill,
        TextAlign = ContentAlignment.MiddleLeft
    };

    private static Icon LoadApplicationIcon()
    {
        string iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "ChromaTaskbar.ico");
        return File.Exists(iconPath) ? new Icon(iconPath) : (Icon)SystemIcons.Application.Clone();
    }

    private static void AddRow(TableLayoutPanel table, int row, string caption, Control value)
    {
        table.Controls.Add(new Label
        {
            Text = caption,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = Color.DimGray
        }, 0, row);
        table.Controls.Add(value, 1, row);
    }
}
