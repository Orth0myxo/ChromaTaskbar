using ChromaTaskbar.Core;

namespace ChromaTaskbar;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        DpiAwareness.TryEnablePerMonitorV2();
        ApplicationConfiguration.Initialize();

        if (!SingleInstanceLease.TryAcquire("Local\\ChromaTaskbar.SingleInstance", out SingleInstanceLease? lease))
        {
            return;
        }

        using (lease)
        {
            try
            {
                using ChromaTaskbarApplicationContext context = new();
                Application.Run(context);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    $"ChromaTaskbar could not start its notification-area icon. No taskbar changes were applied.\r\n\r\n{exception.Message}",
                    "ChromaTaskbar startup failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
