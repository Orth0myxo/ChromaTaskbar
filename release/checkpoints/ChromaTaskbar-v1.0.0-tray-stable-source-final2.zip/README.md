# ChromaTaskbar

ChromaTaskbar adapts the Windows 11 taskbar to the dominant colour of the **foreground maximized application**. Restored, minimized, desktop and Windows shell surfaces keep the taskbar transparent.

## Download and install

- **Installer:** run `ChromaTaskbar-Setup.exe` and choose Install. It installs for the current Windows user and does not require administrator access.
- **Portable:** extract `ChromaTaskbar-Portable.zip` and double-click `Run ChromaTaskbar.cmd` from the extracted folder.

The release is self-contained. Friends do not need Visual Studio, the .NET SDK or a separate .NET runtime. TranslucentTB must already be installed and running for the taskbar appearance to change.

ChromaTaskbar starts in the notification area without opening its settings window. Double-click its tray icon to open settings. Closing that window hides it back to the tray; use the tray menu's **Exit ChromaTaskbar** command to stop the background process and restore the original TranslucentTB settings. The tray menu also pauses and resumes colour detection.

The bundled .NET runtime’s license and third-party notices are in `runtime/LICENSE.txt` and `runtime/ThirdPartyNotices.txt`.

See [INSTALLATION.md](INSTALLATION.md) for install, uninstall and first-run testing steps.

## Features

- Detects the foreground maximized application using Windows window state.
- Samples visible application content in memory and selects a broad representative colour.
- Smoothly transitions colours when switching between maximized applications.
- Keeps the taskbar transparent on the desktop, on normal windows and on shell surfaces such as Start and Task View.
- Retains the last reliable colour after capture failure.
- Runs in the background with tray commands for settings, pause/resume and safe exit.
- Backs up the original TranslucentTB settings before modifying them and restores the exact original file on normal exit.
- Does not save screenshots, send network traffic, inject into processes or change Explorer.

See [FEATURES.md](FEATURES.md) for details and limitations.

## Requirements

- Windows 11, 64-bit.
- TranslucentTB installed and running.
- No development tools or separate .NET runtime required for the release package.

## Privacy and settings protection

Screen samples are processed in memory and are never written to disk. ChromaTaskbar changes only TranslucentTB appearance settings. Before the first change, it saves the original settings under `%LOCALAPPDATA%\ChromaTaskbar\Backups` and restores the original bytes when it exits normally. Backups are retained after uninstall so they remain available for recovery.

The license is MIT; see [LICENSE](LICENSE).

## Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
